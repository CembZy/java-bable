create view view_onis_pacs as /* ALGORITHM=UNDEFINED */
  select
    `pat`.`patient_id`      AS `patient_id`,
    `pat`.`patient_name`    AS `patient_name`,
    `st`.`study_iuid`       AS `study_iuid`,
    `rtp`.`rtplan_iuid`     AS `rtplan_iuid`,
    `rtp`.`rtplan_lable`    AS `rtplan_lable`,
    `rtp`.`instance_fk`     AS `pk`,
    `rtp`.`rtplan_datetime` AS `rtplan_time`,
    `ins`.`created_time`    AS `rtplan_created_time`
  from ((((`rtpacs`.`dcm_patient` `pat`
    join `rtpacs`.`dcm_study` `st`) join `rtpacs`.`dcm_series` `sr`) join `rtpacs`.`dcm_instance` `ins`) join
    `rtpacs`.`dcm_rtplan` `rtp`)
  where ((`rtp`.`instance_fk` = `ins`.`pk`) and (`ins`.`series_fk` = `sr`.`pk`) and (`sr`.`study_fk` = `st`.`pk`) and
         (`st`.`patient_fk` = `pat`.`pk`));

